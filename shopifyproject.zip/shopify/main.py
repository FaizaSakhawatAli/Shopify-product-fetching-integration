from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import shopify
from shopify import Session
import requests

# FastAPI app
app = FastAPI(
    title="Shopify API Integration",
    description="Add products and create orders in Shopify store",
    version="1.0.0",
)

# Shopify Config
SHOP_URL = "qu8zqi-pw.myshopify.com"   # apna store
ACCESS_TOKEN = "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"  # apna token
API_VERSION = "2024-07"

# Set up Shopify Session (for SDK)
session = Session(f"https://{SHOP_URL}", API_VERSION, ACCESS_TOKEN)
shopify.ShopifyResource.activate_session(session)

# ---------------- MODELS ----------------

class Variant(BaseModel):
    option1: str
    price: str
    sku: Optional[str] = None
    inventory_management: Optional[str] = "shopify"
    inventory_quantity: Optional[int] = 0

class Option(BaseModel):
    name: str

class Image(BaseModel):
    src: str

class ProductCreateRequest(BaseModel):
    title: str
    body_html: Optional[str] = "Created via FastAPI"
    variants: List[Variant]
    options: List[Option]
    images: Optional[List[Image]] = []

class ProductCreateResponse(BaseModel):
    id: int
    title: str
    variants: List[dict]
    status: str

class ProductResponse(BaseModel):
    id: int
    title: str
    variant_id: int
    size: str
    price: str
    inventory_quantity: int

class OrderRequest(BaseModel):
    variant_id: int
    quantity: int = 1
    customer_email: str
    customer_name: str

class OrderResponse(BaseModel):
    id: int
    email: str
    customer: dict
    line_items: List[dict]
    status: str


# ---------------- ROUTES ----------------

@app.get("/", tags=["Root"])
def home():
    return {"message": "Shopify API connected successfully!"}


# --- CREATE PRODUCT (REST API) ---
@app.post("/products/create", response_model=ProductCreateResponse, tags=["Products"])
async def create_product(product: ProductCreateRequest):
    try:
        product_data = {
            "product": {
                "title": product.title,
                "body_html": product.body_html,
                "variants": [variant.dict() for variant in product.variants],
                "options": [opt.dict() for opt in product.options],
                "images": [img.dict() for img in product.images] if product.images else []
            }
        }

        url = f"https://{SHOP_URL}/admin/api/{API_VERSION}/products.json"
        headers = {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": ACCESS_TOKEN
        }
        response = requests.post(url, headers=headers, json=product_data)

        if response.status_code != 201:
            raise HTTPException(status_code=response.status_code, detail=response.json())

        product_json = response.json()["product"]
        return {
            "id": product_json["id"],
            "title": product_json["title"],
            "variants": product_json["variants"],
            "status": "success"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating product: {str(e)}")


# --- GET PRODUCTS (SDK) ---
@app.get("/products", response_model=List[ProductResponse], tags=["Products"])
async def get_products(limit: int = 5):
    try:
        products = shopify.Product.find(limit=limit)
        product_list = []
        for product in products:
            for variant in product.variants:
                product_list.append({
                    "id": product.id,
                    "title": product.title,
                    "variant_id": variant.id,
                    "size": getattr(variant, "option1", "N/A"),
                    "price": variant.price,
                    "inventory_quantity": getattr(variant, "inventory_quantity", 0),
                })
        return product_list
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching products: {str(e)}")


# --- CREATE ORDER (SDK) ---
@app.post("/orders/create", response_model=OrderResponse, tags=["Orders"])
async def create_order(order: OrderRequest):
    try:
        # Customer check
        customers = shopify.Customer.search(query=f"email:{order.customer_email}")
        if customers:
            customer = customers[0]
        else:
            customer = shopify.Customer()
            customer.email = order.customer_email
            customer.first_name = order.customer_name.split()[0]
            customer.last_name = " ".join(order.customer_name.split()[1:]) if len(order.customer_name.split()) > 1 else ""
            if not customer.save():
                raise HTTPException(status_code=400, detail=f"Customer creation failed: {customer.errors.full_messages()}")

        # Create Order
        new_order = shopify.Order()
        new_order.email = order.customer_email
        new_order.line_items = [{"variant_id": order.variant_id, "quantity": order.quantity}]
        new_order.customer = {"id": customer.id}
        new_order.financial_status = "paid"

        if new_order.save():
            return {
                "id": new_order.id,
                "email": new_order.email,
                "customer": new_order.customer,
                "line_items": new_order.line_items,
                "status": "success",
            }
        else:
            raise HTTPException(status_code=400, detail=f"Order creation failed: {new_order.errors.full_messages()}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in create_order: {str(e)}")


@app.on_event("shutdown")
def shutdown_event():
    shopify.ShopifyResource.clear_session()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
